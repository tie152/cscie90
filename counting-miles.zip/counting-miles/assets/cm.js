
function get_date() {
  const today = new Date();
  yyyy = today.getFullYear();
  mm = today.getMonth() + 1;
  dd = today.getDate();
  return mm + "/" + dd + "/" + yyyyy;
}